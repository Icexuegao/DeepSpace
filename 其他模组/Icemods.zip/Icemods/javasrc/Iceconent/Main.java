package Iceconent;

import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random v = new Random();
        int i1 = v.nextInt(4);
        for (int i = 0; i <10;i++){

            System.out.println(i1);
        }

    }
}
